package com.android_tp.android_version.com.android_TP_Class_JavaDAO;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.android_tp.android_version.com.android_TP_Class_Java.Usuario;

/**
 * Created by jonathas on 24/01/15.
 */
public class UsuarioDAO {

    private SQLiteDatabase bancoDeDados;

    public  UsuarioDAO(Context context){ // se conecta com o banco // Ex: conect();
        this.bancoDeDados = (new BancoDeDados(context)).getWritableDatabase();
    }


    public Usuario getUsuario(String login,String senha){
        Usuario usuario = null;
        String sqlQuery = "SELECT * FROM Usuarios WHERE " +
                          "login='" + login + "' AND senha='" + senha + "'";
        Cursor cursor = this.bancoDeDados.rawQuery(sqlQuery,null);
        if(cursor.moveToNext()){
            usuario = new Usuario(cursor.getString(0), cursor.getString(1),cursor.getString(2));
        }
        cursor.close();
        return usuario;
    }

    public Cursor getUsuarios(){
        return this.bancoDeDados.rawQuery("SELECT rowid AS _id," +
                "login,nome " +
                "FROM Usuarios ORDER BY login", null);
    }

    public boolean addUsuario(Usuario u){
        try{
            String sqlCmd = "INSERT INTO Usuarios VALUES ('" +
                    u.getLogin() + "'," + " '" + u.getNome() + "', '" +
                    u.getSenha() + "');";
            this.bancoDeDados.execSQL(sqlCmd);
            return true;
        }catch (Exception e){
            Log.e("HelloAppBD", e.getMessage());
            return false;
        }
    }

}
