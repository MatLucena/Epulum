package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android_tp.android_version.R;
import com.android_tp.android_version.com.android_TP_Class_Java.Usuario;
import com.android_tp.android_version.com.android_TP_Class_JavaDAO.UsuarioDAO;


public class Tela_Cadastro_User extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela__cadastro__user);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela__cadastro__user, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void entrarCadastro(View view){
        EditText pegaLogin = (EditText) findViewById(R.id.inputNovoLogin);
        EditText pegaNome = (EditText) findViewById(R.id.inputNovoNome);
        EditText pegaSenha = (EditText) findViewById(R.id.inputNovaSenha);

        Usuario user = new Usuario(pegaLogin.getText().toString(),
                pegaNome.getText().toString(),
                pegaSenha.getText().toString());

        UsuarioDAO userDAO = new UsuarioDAO(this);

        if(userDAO.addUsuario(user)){
            Toast.makeText(this, "Usuário criado com sucesso!", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "Erro ao criar usuário!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
