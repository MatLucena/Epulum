package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android_tp.android_version.R;
import com.android_tp.android_version.com.android_TP_Class_Java.Produto;
import com.android_tp.android_version.com.android_TP_Class_JavaDAO.ProdutoDAO;


public class TelaCadastro extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela_cadastro, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void entrarCadastroProduto(View view){
        EditText pegaNomeProduto = (EditText) findViewById(R.id.inputNomeProduto);
        EditText pegaCategoriaProduto = (EditText) findViewById(R.id.inputCategoriaProduto);
        EditText pegaQuantidadeProduto = (EditText) findViewById(R.id.inputQuantidadeProduto);
        EditText pegaValorProduto = (EditText) findViewById(R.id.inputValorProduto);


        Produto produto = new Produto(pegaNomeProduto.getText().toString(),
                pegaCategoriaProduto.getText().toString(),
                Integer.parseInt(pegaQuantidadeProduto.getText().toString()),
                Double.parseDouble(pegaValorProduto.getText().toString()));

        ProdutoDAO produtoDAO = new ProdutoDAO(this);

        if(produtoDAO.addProduto(produto)){
            Toast.makeText(this, "Produto criado com sucesso!", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "Erro ao criar Produto!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

}
