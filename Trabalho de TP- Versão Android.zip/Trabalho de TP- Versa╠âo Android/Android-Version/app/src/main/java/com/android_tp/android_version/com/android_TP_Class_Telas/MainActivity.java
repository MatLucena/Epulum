package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android_tp.android_version.R;
import com.android_tp.android_version.com.android_TP_Class_Java.Usuario;
import com.android_tp.android_version.com.android_TP_Class_JavaDAO.UsuarioDAO;

public class MainActivity extends Activity {
    Intent intentMenu;
    EditText pegaLogin,pegaSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("helloDebug","Activity principal Iniciada!");
    }

    protected void onStar(){
        super.onStart();
        Log.i("HelloDebug","Método OnStar Executado!");
    }
    @Override
    protected void onResume(){
        super.onResume();
        Log.i("HelloDebug","Método onResume Executado!");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void entrarClicado(View view) {
        intentMenu = new Intent(this, TelaMenu.class);

        pegaLogin = (EditText) findViewById(R.id.inputLogin);
        pegaSenha = (EditText) findViewById(R.id.inputPassword);

        UsuarioDAO userDAO = new UsuarioDAO(this);
        Usuario user = userDAO.getUsuario(pegaLogin.getText().toString(),
                                  pegaSenha.getText().toString());

        if(user != null){
            intentMenu.putExtra("Nome" , user.getNome());

            startActivity(intentMenu);
        }else{
            Toast.makeText(this, "Usuário ou Senha Inválidos!",Toast.LENGTH_SHORT).show();
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.addUser:
                Intent intentMenu = new Intent(this, Tela_Cadastro_User.class);
                startActivity(intentMenu);
                return true;

            case R.id.sobre:
                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                alert.setMessage("Hello World App v1.0")
                        .setNeutralButton("Ok", null).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
