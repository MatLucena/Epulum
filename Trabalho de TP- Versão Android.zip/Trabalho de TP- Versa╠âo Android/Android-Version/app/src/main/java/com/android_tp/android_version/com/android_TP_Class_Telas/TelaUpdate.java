package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android_tp.android_version.R;
import com.android_tp.android_version.com.android_TP_Class_Java.Produto;
import com.android_tp.android_version.com.android_TP_Class_JavaDAO.ProdutoDAO;


public class TelaUpdate extends Activity {
    String nome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_update);
        TextView resetNome = (TextView) findViewById(R.id.ProdutoDaTelaDePesquisa);
        resetNome.setText(null);
        TextView resetCategoria = (TextView) findViewById(R.id.CategoriaDaPesquisa);
        resetCategoria.setText(null);
        TextView resetQuantidade = (TextView) findViewById(R.id.QuantidadeDaPesquisa);
        resetQuantidade.setText(null);
        TextView resetValor = (TextView) findViewById(R.id.ValorDaPesquisa);
        resetValor.setText(null);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela_update, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void PesquisarProduto(View view) {

        EditText pegaProduto = (EditText) findViewById(R.id.inputPesquisaProduto);
        nome = pegaProduto.getText().toString();
        if(nome == null || nome.trim().equals("")){
            Toast.makeText(getApplicationContext(), "Produto não encontrado", Toast.LENGTH_SHORT).show();
        }else {
            Produto produto;
            ProdutoDAO produtoDAO = new ProdutoDAO(this);
            produto = produtoDAO.getProduto(nome);
            nome = produto.getNomeProduto();
            if ((produto != null)) {
                Toast.makeText(getApplicationContext(), "Produto encontrado com sucesso", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão

                EditText editProduto = (EditText)findViewById(R.id.editTextProduto);
                EditText editCategoria = (EditText)findViewById(R.id.editTextCategoria);
                EditText editQuantidade = (EditText)findViewById(R.id.editTextQuantidade);
                EditText editValor = (EditText)findViewById(R.id.editTextValor);
                Button botaoSalvar = (Button)findViewById(R.id.buttonSalvar);

                botaoSalvar.setEnabled(true);
                editProduto.setEnabled(true);

                editCategoria.setEnabled(true);

                editQuantidade.setEnabled(true);

                editValor.setEnabled(true);

                TextView resetNome = (TextView) findViewById(R.id.ProdutoDaTelaDePesquisa);
                resetNome.setText(produto.getNomeProduto());
                TextView resetCategoria = (TextView) findViewById(R.id.CategoriaDaPesquisa);
                resetCategoria.setText(produto.getCategoriaProduto());
                TextView resetQuantidade = (TextView) findViewById(R.id.QuantidadeDaPesquisa);
                resetQuantidade.setText(produto.getCategoriaString());
                TextView resetValor = (TextView) findViewById(R.id.ValorDaPesquisa);
                resetValor.setText(produto.getValorString());

            } else {
                Toast.makeText(getApplicationContext(), "Produto não encontrado", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão
            }
        }
    }

    public void SalvarProduto(View view) {
        ProdutoDAO produtoDAO = new ProdutoDAO(this);
        EditText pegaProduto = (EditText) findViewById(R.id.inputPesquisaProduto);

        EditText editProduto = (EditText)findViewById(R.id.editTextProduto);
        EditText editCategoria = (EditText)findViewById(R.id.editTextCategoria);
        EditText editQuantidade = (EditText)findViewById(R.id.editTextQuantidade);
        EditText editValor = (EditText)findViewById(R.id.editTextValor);

        String novoNome = editProduto.getText().toString();
        String novaCategoria = editCategoria.getText().toString();
        String novaQuantidade = editQuantidade.getText().toString();
        String novoValor = editValor.getText().toString();

       if((!novoNome.equals("")) && (!novaCategoria.equals("")) && (!novaQuantidade.equals("")) && (!novoValor.equals(""))  ){


           //nome = pegaProduto.getText().toString();
            Produto novoProduto = new Produto(novoNome,novaCategoria, (Integer.parseInt(novaQuantidade)), (Double.parseDouble(novoValor)) );

           if(produtoDAO.updateProduto(novoProduto,this.nome)){
               Toast.makeText(this, "Produto Editado com sucesso!", Toast.LENGTH_SHORT).show();
           }else{
               Toast.makeText(this, "Erro ao Editar o Produto!", Toast.LENGTH_SHORT).show();
           }


       }else{
           Toast.makeText(this, "Todos os campos são obrigatórios favor Preecher!", Toast.LENGTH_SHORT).show();
       }


    }
}
