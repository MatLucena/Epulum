package com.android_tp.android_version.com.android_TP_Class_Java;

import java.io.Serializable;

/**
 * Created by jonathas on 24/01/15.
 */
public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    private String login,nome,senha;

    public Usuario(String l, String n, String s){
        this.login = l;
        this.nome = n;
        this.senha = s;
    }



    public String getNome(){
        return this.nome;
    }
    public String getLogin(){
        return this.login;
    }
    public String getSenha(){
        return this.senha;
    }


}
