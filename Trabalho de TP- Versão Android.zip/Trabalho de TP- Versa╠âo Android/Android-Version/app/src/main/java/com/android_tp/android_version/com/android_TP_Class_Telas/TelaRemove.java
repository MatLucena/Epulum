package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android_tp.android_version.R;
import com.android_tp.android_version.com.android_TP_Class_Java.Produto;
import com.android_tp.android_version.com.android_TP_Class_JavaDAO.ProdutoDAO;


public class TelaRemove extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_remove);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela_remove, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void RemoverProduto(View view) {

        EditText pegaProduto = (EditText) findViewById(R.id.inputProdutoRemovido);
        String nome = pegaProduto.getText().toString();
        if(nome.trim().equals("")){
            Toast.makeText(getApplicationContext(), "Erro ao remover Produto, favor inserir o nome do produto", Toast.LENGTH_SHORT).show();
        }else {
            Produto produto;
            ProdutoDAO produtoDAO = new ProdutoDAO(this);
            produto = produtoDAO.getProduto(nome);

            if (produtoDAO.RemoveProduto(produto)) {
                Toast.makeText(getApplicationContext(), "Produto Removido com sucesso", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "ERRO AO REMOVER PRODUTO", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
