package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.ListActivity;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.Menu;
import android.view.MenuItem;

import com.android_tp.android_version.R;
import com.android_tp.android_version.com.android_TP_Class_JavaDAO.ProdutoDAO;


public class TelaListarProdutos extends ListActivity {

    public ProdutoDAO produtoDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.produtoDAO = new ProdutoDAO(this);

        SimpleCursorAdapter dados = new SimpleCursorAdapter(this,
                R.layout.activity_tela_listar_produtos,
                produtoDAO.getProdutos(),
                new String[]{"nome", "categoria", "quantidade", "valor"},
                new int[]{R.id.NomeDoProduto, R.id.NomeDaCategoria, R.id.QuantidadeDaQuantidade, R.id.ValorProduto},
                0);

        setListAdapter(dados);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela_listar_produtos, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
