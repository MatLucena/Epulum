package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android_tp.android_version.R;
import com.android_tp.android_version.com.android_TP_Class_Java.Produto;
import com.android_tp.android_version.com.android_TP_Class_JavaDAO.ProdutoDAO;


public class TelaPesquisa extends Activity {

    public ProdutoDAO produtoDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pesquisa);
        TextView resetNome = (TextView) findViewById(R.id.ProdutoDaTelaDePesquisa);
        resetNome.setText(null);
        TextView resetCategoria = (TextView) findViewById(R.id.CategoriaDaPesquisa);
        resetCategoria.setText(null);
        TextView resetQuantidade = (TextView) findViewById(R.id.QuantidadeDaPesquisa);
        resetQuantidade.setText(null);
        TextView resetValor = (TextView) findViewById(R.id.ValorDaPesquisa);
        resetValor.setText(null);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela_pesquisa, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void PesquisarProduto(View view) {

        EditText pegaProduto = (EditText) findViewById(R.id.inputPesquisaProduto);
        String nome = pegaProduto.getText().toString();
        if(nome == null || nome.trim().equals("")){
            Toast.makeText(getApplicationContext(), "Produto não encontrado", Toast.LENGTH_SHORT).show();
        }else {
            Produto produto;
            ProdutoDAO produtoDAO = new ProdutoDAO(this);
            produto = produtoDAO.getProduto(nome);
            if ((produto != null)) {
                Toast.makeText(getApplicationContext(), "Produto encontrado com sucesso", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão

                TextView resetNome = (TextView) findViewById(R.id.ProdutoDaTelaDePesquisa);
                resetNome.setText(produto.getNomeProduto());
                TextView resetCategoria = (TextView) findViewById(R.id.CategoriaDaPesquisa);
                resetCategoria.setText(produto.getCategoriaProduto());
                TextView resetQuantidade = (TextView) findViewById(R.id.QuantidadeDaPesquisa);
                resetQuantidade.setText(produto.getCategoriaString());
                TextView resetValor = (TextView) findViewById(R.id.ValorDaPesquisa);
                resetValor.setText(produto.getValorString());

            } else {
                Toast.makeText(getApplicationContext(), "Produto não encontrado", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão
            }
        }
    }
    public void ResetarLista(View view){
        TextView resetNome = (TextView) findViewById(R.id.ProdutoDaTelaDePesquisa);
        resetNome.setText(null);
        TextView resetCategoria = (TextView) findViewById(R.id.CategoriaDaPesquisa);
        resetCategoria.setText(null);
        TextView resetQuantidade = (TextView) findViewById(R.id.QuantidadeDaPesquisa);
        resetQuantidade.setText(null);
        TextView resetValor = (TextView) findViewById(R.id.ValorDaPesquisa);
        resetValor.setText(null);
        Toast.makeText(getApplicationContext(), "Pesquisa resetada, realize uma nova busca", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão


    }
}
