package com.android_tp.android_version.com.android_TP_Class_JavaDAO;
/**
 * Created by jonathas on 24/01/15.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BancoDeDados extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "HelloWorldApp.db";

    private static final String SQL_CREATE_TABLES_USUARIOS = "CREATE TABLE IF NOT EXISTS Usuarios(" +
            "login TEXT PRIMARY KEY," +
            "nome TEXT," +
            "senha TEXT )";

    private static final String SQL_CREATE_TABLES_PRODUTOS = "CREATE TABLE IF NOT EXISTS Produtos(" +
            "nome TEXT PRIMARY KEY,"+
            "categoria TEXT," +
            "quantidade INT," +
            "valor DOUBLE )";

    private static final String SQL_POPULATE_TABLES_PRODUTOS = "INSERT INTO Produtos " +
            "VALUES ('Chuveiro Acqua Plus', 'Material Hidraulico', '5', '40.99' )";

    private static final String SQL_POPULATE_TABLES_USUARIOS = "INSERT INTO Usuarios " +
            "VALUES ('admin', 'Jhonn', 'admin')";

    private static final String SQL_DELETE_TABLES = "DROP TABLE IF EXISTS Usuarios ";

    public BancoDeDados(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLES_USUARIOS);
        db.execSQL(SQL_POPULATE_TABLES_USUARIOS);
        db.execSQL(SQL_CREATE_TABLES_PRODUTOS);
        db.execSQL(SQL_POPULATE_TABLES_PRODUTOS);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_TABLES);
        onCreate(db);
    }
}
