package com.android_tp.android_version.com.android_TP_Class_Java;

/**
 * Created by jonathas on 24/01/15.
 */
public class Produto {
    private static final long serialVersionUID = 1L;
    private String categoria,nome;
    private int quantidade;
    private double valor;

    public Produto(String N,String C, int Q, double V){
        this.nome = N;
        this.categoria = C;
        this.quantidade = Q;
        this.valor = V;
    }
    public String getNomeProduto(){
        return this.nome;
    }
    public String getCategoriaProduto(){
        return this.categoria;
    }
    public String getCategoriaString() {return this.quantidade + " unidades";}
    public String getValorString() {return " Valor Unitário " + this.valor;}
    public int getQuantidadeProduto(){return this.quantidade;}
    public double getValorProduto(){return this.valor;}


}
