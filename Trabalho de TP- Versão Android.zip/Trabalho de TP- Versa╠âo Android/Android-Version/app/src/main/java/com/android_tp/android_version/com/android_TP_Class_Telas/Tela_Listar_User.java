package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.ListActivity;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;

import com.android_tp.android_version.R;
import com.android_tp.android_version.com.android_TP_Class_JavaDAO.UsuarioDAO;


public class Tela_Listar_User extends ListActivity {

    private UsuarioDAO userDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.userDAO = new UsuarioDAO(this);

        SimpleCursorAdapter dados = new SimpleCursorAdapter(this,
                R.layout.user_line,
                userDAO.getUsuarios(),
                new String[]{"login", "nome"},
                new int[]{R.id.textView4, R.id.textView5},
                0);

        setListAdapter(dados);
    }
}
