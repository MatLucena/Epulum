package com.android_tp.android_version.com.android_TP_Class_JavaDAO;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.android_tp.android_version.com.android_TP_Class_Java.Produto;

/**
 * Created by jonathas on 24/01/15.
 */
public class ProdutoDAO {
    private SQLiteDatabase bancoDeDados;

    public  ProdutoDAO(Context context){ // se conecta com o banco // Ex: conect();
        this.bancoDeDados = (new BancoDeDados(context)).getWritableDatabase();
    }

    public Cursor getProdutos(){ // faz a listagem dos produtos
        return this.bancoDeDados.rawQuery("SELECT rowid AS _id," +
                "nome, categoria, quantidade, valor " +
                "FROM Produtos ORDER BY nome", null);
    }


    public Produto getProduto(String nome){
        Produto produto = null;
        String sqlQuery = "SELECT * FROM Produtos WHERE " +
                "nome LIKE '" + nome + "%'";
        Cursor cursor = this.bancoDeDados.rawQuery(sqlQuery,null);
        if(cursor.moveToNext()){
            produto = new Produto(cursor.getString(0), cursor.getString(1),cursor.getInt(2),cursor.getDouble(3));
        }
        cursor.close();
        return produto;
    }

    public boolean addProduto(Produto p){
        try{
            String sqlCmd = "INSERT INTO Produtos VALUES ('" +
                    p.getNomeProduto() + "', '"+ p.getCategoriaProduto() + "', '" +
                    p.getQuantidadeProduto() + "', '" + p.getValorProduto() + "');";
            this.bancoDeDados.execSQL(sqlCmd);
            return true;
        }catch (Exception e){
            Log.e("Deu erro ao tentar adicionar por algum motivo", e.getMessage());
            return false;
        }
    }
    public boolean RemoveProduto(Produto p){
        try{
            String sqlCmd = "DELETE FROM Produtos WHERE nome='" + p.getNomeProduto() + "'";
            this.bancoDeDados.execSQL(sqlCmd);
            return true;
        }catch (Exception e){
            Log.e("Deu erro ao tentar remover por algum motivo", e.getMessage());
            return false;
        }
    }

    public boolean updateProduto(Produto p, String nome){
        try{
            String sqlCmd = "UPDATE Produtos SET " +
                    "categoria='" + p.getCategoriaProduto() + "', " +
                    "valor ='" + p.getValorProduto() + "', " +
                    "quantidade ='" + p.getQuantidadeProduto() + "', " +
                    "nome ='" + p.getNomeProduto() + "' " +
                    "WHERE nome ='" + nome + "';";
            this.bancoDeDados.execSQL(sqlCmd);
            return true;
        }catch (Exception e){
            Log.e("Deu erro ao tentar editar o produto por algum motivo", e.getMessage());
            return false;
        }

    }

}
