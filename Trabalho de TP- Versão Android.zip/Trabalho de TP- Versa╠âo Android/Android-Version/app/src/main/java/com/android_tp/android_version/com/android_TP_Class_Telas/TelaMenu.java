package com.android_tp.android_version.com.android_TP_Class_Telas;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android_tp.android_version.R;


public class TelaMenu extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_menu);

        Intent intent = getIntent();
        String login = intent.getStringExtra("Nome");

        TextView textView3 = (TextView) findViewById(R.id.menuTXT);
        textView3.setText(Html.fromHtml("       Olá Usuário  <b> " + login + " </b> Seja Bem Vindo!"));
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

            Intent intentListar = new Intent(this, Tela_Listar_User.class);
            startActivity(intentListar);

        return super.onOptionsItemSelected(item);
    }

    public void entrarCadastroProduto(View view) {
        Toast.makeText(getApplicationContext(), "Olá a tela de cadastro de Produtos", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão
        Intent intent = new Intent(this, TelaCadastro.class);
        startActivity(intent);
    }

    public void entrarListar(View view) {
        Toast.makeText(getApplicationContext(), "Bem vindo a tela de listagem", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão
        Intent intent = new Intent(this, TelaListarProdutos.class);
        startActivity(intent);
    }

    public void entrarPesquisar(View view) {
        Toast.makeText(getApplicationContext(), "Bem vindo a tela de pesquisa", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão
        Intent intent = new Intent(this, TelaPesquisa.class);
        startActivity(intent);

    }

    public void entrarAlterar(View view) {
        Toast.makeText(getApplicationContext(), "Bem vindo a tela para editar o produto", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão
        Intent intent = new Intent(this, TelaUpdate.class);
        startActivity(intent);

    }

    public void entrarDeletar(View view) {
        Toast.makeText(getApplicationContext(), "Olá a tela de remoção", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão
        Intent intent = new Intent(this, TelaRemove.class);
        startActivity(intent);

    }

    public void DeslogarSistema(View view) {
        Toast.makeText(getApplicationContext(), "Usuário Deslogado", Toast.LENGTH_SHORT).show(); //Mostrar olá ao clicar no botão
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
